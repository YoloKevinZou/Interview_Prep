class Customer:

	def __init__(self, user_id, name, latitude, longitude):
		self.user_id = user_id
		self.name = name
		self.latitude = latitude
		self.longitude = longitude
	