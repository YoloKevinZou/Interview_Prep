import unittest
from customercollectiontest import *
from fileparsertest import *

def __main__():
	collection_test = CustomerCollectionTest()
	file_parse_test = FileParseTest()

if __name__ == '__main__':
    main()